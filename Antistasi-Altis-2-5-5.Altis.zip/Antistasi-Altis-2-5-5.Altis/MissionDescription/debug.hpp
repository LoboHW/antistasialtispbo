allowFunctionsLog = 1;
enableDebugConsole[] = {
    "76561198977000729", //antistasi_official
    "76561197981991967", //Bob Murphy
    "76561198075487693", //Meerkat
    "76561198011383725", //Spoffy
    "76561198105754435", //Wurzel
    "76561197993612092", //DoomMetal
    "76561198304402577", //FrostsBite
    "76561198087513761", //Hakon
    "76561198000461190", //John Jordan
    "76561198016623887", //Lazejun
    "76561197991835568", //Tad
    "76561198068206504", //poweredbypot
    "76561197969814277" //Giddi
};
allowFunctionsRecompile = 1;

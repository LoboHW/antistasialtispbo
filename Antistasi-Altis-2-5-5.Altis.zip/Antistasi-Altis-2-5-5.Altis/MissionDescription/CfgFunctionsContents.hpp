// In map template description.ext use:
// #include "MissionDescription\CfgFunctionsContents.hpp"

#include "..\functions.hpp"
#include "..\JeroenArsenal\functions.hpp"
#include "..\Garage\functions.hpp"
//#include "..\Collections\functions.hpp"

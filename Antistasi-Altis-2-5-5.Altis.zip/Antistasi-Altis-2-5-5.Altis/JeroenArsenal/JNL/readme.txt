Call jn_fnc_logistics_addAction on a cargo type to add the load action
